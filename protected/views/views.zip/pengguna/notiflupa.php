<?php
	$this->pageTitle=Yii::app()->name . ' - Lupa Password';
	$this->breadcrumbs=array(
		'Lupa Password',
	);
?>

<h1>Lupa Password</h1>
<br/>
<p>Password telah dikirimkan ke alamat e-mail pendaftaran anda!.</p>