<?php
	$this->pageTitle=Yii::app()->name . ' - Pendaftaran';
	$this->breadcrumbs=array(
		'Pendaftaran',
	);
?>

<br/>
<p> Pendaftaran gagal!<br/>
Email anda salah.<p>