<div class="view" style="float: left" align="center">

        
	<span>
        <img src="<?php echo Yii::app()->request->baseUrl.'/images/gallery/' .$data->url?>" width="200" height="100"/>

    </span>
    <div style="clear:both;"></div>
	
</div>