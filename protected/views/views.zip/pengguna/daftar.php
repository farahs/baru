<?php
	$this->pageTitle=Yii::app()->name . ' - Pendaftaran';
	$this->breadcrumbs=array(
		'Pendaftaran',
	);
?>

<br/>
<p> Pendaftaran berhasil!<br/>
Email verifikasi telah dikirimkan ke alamat email anda.<p>