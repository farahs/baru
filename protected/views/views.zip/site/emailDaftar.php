<?php
	echo 'Hai '.$pengguna->nama.'<br/> Anda telah melakukan register dengan :<br/>
	Username  :'.$pengguna->user.'<br/>
	Password  :'.$pengguna->pass.'<br/>
	Klik link berikut untuk melakukan validasi http://localhost/verifikasi.html?id='.$kode;
?>