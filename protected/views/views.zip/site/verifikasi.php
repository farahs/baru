<?php
	$this->pageTitle=Yii::app()->name . ' - Verifikasi';
	$this->breadcrumbs=array(
		'Verifikasi',
	);
?>
<h1>Verifikasi</h1>

<p>Terima kasih anda telah melakukan verifikasi.</p>
