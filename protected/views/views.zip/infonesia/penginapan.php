<?php

?>

    <ul>
        <li><?php echo CHtml::encode($data->penginapan); ?></li>
	</ul>
