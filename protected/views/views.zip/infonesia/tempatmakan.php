<?php
/* @var $this ReviewController */
/* @var $data Review */
?>


    <ul>
        <li><?php echo CHtml::encode($data->tempatmakan); ?></li>
	</ul>
