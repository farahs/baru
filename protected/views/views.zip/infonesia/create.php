<?php
/* @var $this InfonesiaController */
/* @var $model Infonesia */

$this->breadcrumbs=array(
	'Infonesia'=>array('index'),
	'Create',
);

?>

<h1>Create Infonesia</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>