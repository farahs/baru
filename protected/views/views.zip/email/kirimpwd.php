<?php
	echo 'Hai '.$profil->nama.'<br/> Anda telah melakukan register dengan :<br/>
	Username  :'.$pengguna->username.'<br/>
	Password  :'.$pengunjungterdaftar->password.'<br/>
	Klik link berikut untuk melakukan validasi http://localhost/verifikasi.html?id='.$pengguna->kodeDaftar;

	echo '<br/> <br/> Exoticnesia'
?>